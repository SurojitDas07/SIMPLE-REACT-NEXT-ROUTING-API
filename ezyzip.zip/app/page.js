"use client"
import './globals.css'
import React, { useState } from 'react'
import axios, { Axios } from 'axios'
import { images } from '@/next.config'

const page = () => {
  const [Images, setImages] = useState([])
  const getImages = async()=>{

   try {
    const responce = await axios.get("https://picsum.photos/v2/list")
    const data = responce.data
    setImages(data)
    console.log(Images)
   } catch (error) {
    console.error("error fatching images");
   }
  }
  return (
    <div>
      <button onClick={getImages} className='imgbtn'>Get Images</button>
      <div className='div'>
        {Images.map((elem)=>{
        return <img 
        src={elem.download_url}
        width={350}
        height={300}
        className='cls'
        />

        })}
      </div>
    </div>
  )
}

export default page