import React from "react";

const page = () => {
  return (
    <div>
      <section class="background firstSection" id="home">
        <div class="box-main">
          <div class="firstHalf">
            <p class="text-big">The Future of Education Us Here..</p>
            <p class="text-small">
              in this world 7b people we need to love and edcutatevthe future of
              education ushere Lorem ipsum dolor sit amet, consectetur
              adipisicing elit. Omnis, iusto.
            </p>
            <div class="buttons">
              <button class="btn">Subscribe</button>
              <button class="btn">Watch video</button>
            </div>
          </div>
          <div class="secondHalf">
            <img
              src="http://source.unsplash.com/900x900/?coding,laptop"
              alt="img faild"
            />
          </div>
        </div>
      </section>

      <section class="secction" id="About">
        <div class="paras">
          <p class="sectionTag text-big">The End of Your Search is Here</p>
          <p class="sectionSubTag text-small">
            Education is the transmission of knowledge, skills, and character
            traits. There are many debates about its precise definition, for
            example, about which aims it tries to achieve. A further issue is
            whether part of the meaning of education is that the change in the
            student is an improvement. Some researchers stress the role of
            critical thinking to distinguish education from indoctrination.
            These disagreements affect how to identify, measure, and improve
            forms of education. The term can also refer to the mental states and
            qualities of educated people. Additionally, it can mean the academic
            field studying education.
          </p>
        </div>
        <div class="thumbnail">
          <img
            src="http://source.unsplash.com/900x900/?coding,apple"
            alt="faild"
            class="imgFluid"
          />
        </div>
      </section>

      <section class="secction section-Left">
        <div class="paras">
          <p class="sectionTag text-big">
            Tranceforming Education is Here in India
          </p>
          <p class="sectionSubTag text-small">
            There are many types of education. Formal education happens in a
            complex institutional framework, like public schools. Non-formal
            education is also structured but happens outside the formal
            schooling system. Informal education is unstructured learning
            through daily experiences. Formal and non-formal education are
            divided into levels. They include early childhood education, primary
            education, secondary education, and tertiary education. Other
            classifications focus on the teaching method, like teacher-centered
            and student-centered education. Forms of education can also be
            distinguished by subject, like science education, language
            education, and physical education.
          </p>
        </div>
        <div class="thumbnail">
          <img
            src="http://source.unsplash.com/900x900/?coding,hack"
            alt="faild"
            class="imgFluid"
          />
        </div>
      </section>
      <section class="secction">
        <div class="paras">
          <p class="sectionTag text-big">Lets Grow Together</p>
          <p class="sectionSubTag text-small">
            There are many types of education. Formal education happens in a
            complex institutional framework, like public schools. Non-formal
            education is also structured but happens outside the formal
            schooling system. Informal education is unstructured learning
            through daily experiences. Formal and non-formal education are
            divided into levels. They include early childhood education, primary
            education, secondary education, and tertiary education. Other
            classifications focus on the teaching method, like teacher-centered
            and student-centered education. Forms of education can also be
            distinguished by subject, like science education, language
            education, and physical education.
          </p>
        </div>
        <div class="thumbnail">
          <img
            src="http://source.unsplash.com/900x900/?coding,java"
            alt="faild"
            s="imgFluid"
          />
        </div>
      </section>
      <hr />
      <section class="contact" id="Contact">
        <h2 class="text-center">Contact Us</h2>
        <div class="form">
          <input
            class="form-input"
            type="phone"
            name="name"
            id="name"
            placeholder="Enter Your Phone"
          />
          <input
            class="form-input"
            type="text"
            name="name"
            id="name"
            placeholder="Enter Your Name"
          />
          <input
            class="form-input"
            type="email"
            name="name"
            id="name"
            placeholder="Enter Your Email"
          />
          <textarea
            class="form-input"
            name="text"
            id="text"
            cols="30"
            rows="10"
            placeholder="Ellaborate your concern"
          ></textarea>
          <button class="btn-dark">Submit</button>
        </div>
      </section>
      <footer class="background">
        <p class="text-footer">Copyright &copy; 2023 - All rights reserved</p>
      </footer>
    </div>
  );
};

export default page;
