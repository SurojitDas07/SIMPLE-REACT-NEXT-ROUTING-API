import React from 'react'
import './page.css'

const page = () => {
  return (
    <>
       <div className="container">
        <h1>Welcome to Our  Website | contact now</h1>
        <form action="/" id="Contact">
            <input type="text" name="name" id="name" placeholder="Enter your Name"/>
            <input type="text" name="age" id="age" placeholder="Enter your Age"/>
            <input type="text" name="gender" id="gender" placeholder="Enter your Gender"/>
            <textarea name="address" id="address" cols="30" rows="10" placeholder="Enter your address"></textarea>
            <textarea name="more" id="more" cols="30" rows="10" placeholder="more about you"></textarea>
            </form>
            <button>Submit</button>
         </div>
    </>
  )
}

export default page