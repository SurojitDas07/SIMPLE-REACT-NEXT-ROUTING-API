import React from 'react'

const page = () => {
  return (
    <div>More</div>
  )
}

export default page